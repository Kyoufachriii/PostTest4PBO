/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kopi;

import java.util.Scanner;
import model.*;
import service.KopiService;

/**
 *
 * @author fachr
 */
public class KopiNusantara {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        KopiService service = new KopiService();

        int pilihan;
        do {
            System.out.println("\n============      KataKopi      =============");
            System.out.println("===     Selamat Datang Di KataKopiii      ===");
            System.out.println("Ini Dia Fitur-Fitur Yang Ada Di KataKopiii");
            System.out.println("1. Tambah Kopi");
            System.out.println("2. Lihat Daftar Kopi");
            System.out.println("3. Ubah Data Kopi");
            System.out.println("4. Hapus Data Kopi");
            System.out.println("5. Cari Kopi");
            System.out.println("6. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = input.nextInt();
            input.nextLine();

            switch (pilihan) {
                case 1:
                    System.out.print("Nama kopi: ");
                    String nama = input.nextLine().trim();

                    System.out.print("Asal kopi: ");
                    String asal = input.nextLine().trim();

                    String jenis;
                    while (true) {
                        System.out.print("Jenis kopi (Arabika/Robusta/Liberika): ");
                        jenis = input.nextLine().trim();
                        if (jenis.equalsIgnoreCase("Arabika") ||
                            jenis.equalsIgnoreCase("Robusta") ||
                            jenis.equalsIgnoreCase("Liberika")) break;
                        System.out.println("Jenis kopi hanya Arabika, Robusta, atau Liberika.");
                    }

                    String asam;
                    while (true) {
                        System.out.print("Keasaman (Rendah/Sedang/Tinggi): ");
                        asam = input.nextLine().trim();
                        if (asam.equalsIgnoreCase("Rendah") ||
                            asam.equalsIgnoreCase("Sedang") ||
                            asam.equalsIgnoreCase("Tinggi")) break;
                        System.out.println("Tingkat keasaman hanya: Rendah, Sedang, Tinggi.");
                    }

                    System.out.print("Aroma kopi: ");
                    String aroma = input.nextLine().trim();

                    Kopi kopiBaru;
                    if (jenis.equalsIgnoreCase("Arabika")) {
                        kopiBaru = new KopiArabika(nama, asal, asam, aroma);
                    } else if (jenis.equalsIgnoreCase("Robusta")) {
                        kopiBaru = new KopiRobusta(nama, asal, asam, aroma);
                    } else {
                        kopiBaru = new KopiLiberika(nama, asal, asam, aroma);
                    }
                    service.tambahKopi(kopiBaru);
                    break;

                case 2:
                    service.tampilkanKopi();
                    break;

                case 3:
                    if (service.isEmpty()) {
                        System.out.println("Data kopi masih kosong.");
                        break;
                    }

                    service.tampilkanKopi();
                    System.out.print("Kopi mana yang mau kamu ubah? (Nomor): ");
                    int ubah = input.nextInt() - 1;
                    input.nextLine();

                    System.out.print("Nama baru: ");
                    String nBaru = input.nextLine().trim();

                    System.out.print("Asal baru: ");
                    String aBaru = input.nextLine().trim();

                    String jBaru;
                    while (true) {
                        System.out.print("Jenis baru (Arabika/Robusta/Liberika): ");
                        jBaru = input.nextLine().trim();
                        if (jBaru.equalsIgnoreCase("Arabika") ||
                            jBaru.equalsIgnoreCase("Robusta") ||
                            jBaru.equalsIgnoreCase("Liberika")) break;
                        System.out.println("Jenis kopi hanya Arabika, Robusta, atau Liberika.");
                    }

                    String kBaru;
                    while (true) {
                        System.out.print("Keasaman baru (Rendah/Sedang/Tinggi): ");
                        kBaru = input.nextLine().trim();
                        if (kBaru.equalsIgnoreCase("Rendah") ||
                            kBaru.equalsIgnoreCase("Sedang") ||
                            kBaru.equalsIgnoreCase("Tinggi")) break;
                        System.out.println("Tingkat keasaman hanya: Rendah, Sedang, Tinggi.");
                    }

                    System.out.print("Aroma baru: ");
                    String arBaru = input.nextLine().trim();

                    Kopi kopiUbah;
                    if (jBaru.equalsIgnoreCase("Arabika")) {
                        kopiUbah = new KopiArabika(nBaru, aBaru, kBaru, arBaru);
                    } else if (jBaru.equalsIgnoreCase("Robusta")) {
                        kopiUbah = new KopiRobusta(nBaru, aBaru, kBaru, arBaru);
                    } else {
                        kopiUbah = new KopiLiberika(nBaru, aBaru, kBaru, arBaru);
                    }
                    service.ubahKopi(ubah, kopiUbah);
                    break;

                case 4:
                    service.tampilkanKopi();
                    System.out.print("Masukkan nomor kopi yang mau dihapus: ");
                    int hapus = input.nextInt();
                    input.nextLine();
                    service.hapusKopi(hapus - 1);
                    break;

                 case 5:
                    if (service.isEmpty()) {
                        System.out.println("Data kopi masih kosong.");
                        break;
                    }

                    System.out.println("Cari kopi berdasarkan:");
                    System.out.println("1. Nama");
                    System.out.println("2. Asal");
                    System.out.println("3. Aroma");
                    System.out.print("Pilih (1/2/3): ");
                    int kriteria = input.nextInt();
                    input.nextLine();
                    
                    if (kriteria < 1 || kriteria > 3) {
                        System.out.println("Pilihan kriteria pencarian tidak valid.");
                        break;
                    }

                    System.out.print("Masukkan kata kunci: ");
                    String keyword = input.nextLine().trim();
                    service.cariKopi(kriteria, keyword);
                    break;

                case 6:
                    System.out.println("Terima kasih telah menggunakan KataKopiii!");
                    break;

                default:
                    System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 6);

        input.close();
    }
}