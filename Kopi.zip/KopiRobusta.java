/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author fachr
 */
public class KopiRobusta extends Kopi{ 
    public KopiRobusta(String nama, String asal, String keasaman, String aroma) {
        super(nama, asal, "Robusta", keasaman, aroma);
    }
    @Override 
    public String getDeskripsi() {
        return "Kopi Robusta terkenal karena rasanya yang pahit, body tebal, dan kadar kafeinnya yang tinggi.";
    }

}