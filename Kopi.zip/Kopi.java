/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author fachr
 */
public abstract class Kopi {
    private String nama;
    private String asal;
    private String jenis;
    private String keasaman;
    private String aroma;

    public Kopi(String nama, String asal, String jenis, String keasaman, String aroma) {
        this.nama = nama;
        this.asal = asal;
        this.jenis = jenis;
        this.keasaman = keasaman;
        this.aroma = aroma;
    }

    public abstract String getDeskripsi();
    
    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getAsal() { return asal; }
    public void setAsal(String asal) { this.asal = asal; }

    public String getJenis() { return jenis; }
    public void setJenis(String jenis) { this.jenis = jenis; }

    public String getKeasaman() { return keasaman; }
    public void setKeasaman(String keasaman) { this.keasaman = keasaman; }

    public String getAroma() { return aroma; }
    public void setAroma(String aroma) { this.aroma = aroma; }
}