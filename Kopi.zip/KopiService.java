/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import model.*;

/**
 *
 * @author fachr
 */
import java.util.ArrayList;

public class KopiService {
    private ArrayList<Kopi> daftarKopi = new ArrayList<>();

    public KopiService() {
        // Arabika
        daftarKopi.add(new KopiArabika("Kopi Gayo", "Aceh", "Sedang", "Floral"));
        daftarKopi.add(new KopiArabika("Kopi Toraja", "Sulawesi Selatan", "Tinggi", "Earthy"));
        daftarKopi.add(new KopiArabika("Kopi Kintamani", "Bali", "Tinggi", "Fruity"));
        daftarKopi.add(new KopiArabika("Kopi Lintong", "Sumatera Utara", "Sedang", "Spicy"));

        // Robusta
        daftarKopi.add(new KopiRobusta("Kopi Lampung", "Lampung", "Rendah", "Strong"));
        daftarKopi.add(new KopiRobusta("Kopi Jawa", "Jawa Timur", "Sedang", "Smoky"));
        daftarKopi.add(new KopiRobusta("Kopi Flores Bajawa", "NTT", "Sedang", "Chocolate"));

        // Liberika
        daftarKopi.add(new KopiLiberika("Kopi Liberika Rangsang", "Riau", "Rendah", "Woody"));
        daftarKopi.add(new KopiLiberika("Kopi Liberika Jambi", "Jambi", "Sedang", "Caramel"));
        daftarKopi.add(new KopiLiberika("Kopi Liberika Kalimantan", "Kalimantan", "Rendah", "Nutty"));
    }

    public void tambahKopi(Kopi kopi) {
        daftarKopi.add(kopi);
        System.out.println("Yeayy kamu berhasil menambahkan kopi baru.");
    }

    public void tampilkanKopi() {
        if (daftarKopi.isEmpty()) {
            System.out.println("Belum ada data kopi.");
            return;
        }

        System.out.println("\n========      DAFTAR KOPI      =========");
        int i = 1;
        for (Kopi kopi : daftarKopi) {
            System.out.println(i + ". " + kopi.getNama() + " (" + kopi.getJenis() + ")");
            System.out.println("   Asal     : " + kopi.getAsal());
            System.out.println("   Keasaman : " + kopi.getKeasaman());
            System.out.println("   Aroma    : " + kopi.getAroma());
            System.out.println("   Deskripsi: " + kopi.getDeskripsi()); 

                if (kopi instanceof KopiArabika) {
                    System.out.println("   Info Teknis: Kandungan Kafein Rendah hingga Sedang (kurang lebih 1.5%). Jenis kopi paling populer.");
                    System.out.println("   Rekomendasi Seduh: Pour Over (V60/Chemex) untuk menonjolkan aroma bunga dan buah.");
                } else if (kopi instanceof KopiRobusta) {
                    System.out.println("   Info Teknis: Kandungan Kafein Tinggi (kurang lebih 2.5%). Sering digunakan untuk espresso atau kopi instan.");
                    System.out.println("   Rekomendasi Seduh: Espresso atau Tubruk karena menghasilkan crema tebal dan body kuat.");
                } else if (kopi instanceof KopiLiberika) {
                    System.out.println("   Info Teknis: Kandungan Kafein Sangat Rendah (kurang lebih 1.2%). Termasuk jenis langka dengan produksi terbatas.");
                    System.out.println("   Rekomendasi Seduh: French Press untuk menangkap body dan keunikan rasa yang kompleks.");
                }
            System.out.println();
            i++;
        }
    }
         
    public void ubahKopi(int index, Kopi kopiBaru) {
        if (index >= 0 && index < daftarKopi.size()) {
            daftarKopi.set(index, kopiBaru);
            System.out.println("Kamu udah berhasil ngubah kopi ini");
        } else {
            System.out.println("Nomor kopi tidak ditemukan.");
        }
    }

    public void hapusKopi(int index) {
        if (index >= 0 && index < daftarKopi.size()) {
            daftarKopi.remove(index);
            System.out.println("Kopinya udah berhasil kamu hapus");
        } else {
            System.out.println("️Nomor kopi tidak ditemukan.");
        }
    }

     public void cariKopi(int kriteria, String keyword) {
        if (daftarKopi.isEmpty()) {
            System.out.println(" Belum ada data kopi.");
            return;
        }

        System.out.println("\n======== HASIL PENCARIAN ========");
        boolean found = false;
        int i = 1; 

        for (Kopi kopi : daftarKopi) {
            boolean cocok = switch (kriteria) {
                case 1 -> kopi.getNama().toLowerCase().contains(keyword.toLowerCase());
                case 2 -> kopi.getAsal().toLowerCase().contains(keyword.toLowerCase());
                case 3 -> kopi.getAroma().toLowerCase().contains(keyword.toLowerCase());
                default -> false;
            };

            if (cocok) {
                System.out.println(i + ". " + kopi.getNama() + " (" + kopi.getJenis() + ")");
                System.out.println("   Asal     : " + kopi.getAsal());
                System.out.println("   Keasaman : " + kopi.getKeasaman());
                System.out.println("   Aroma    : " + kopi.getAroma());
                
                // PENTING: Panggil getDeskripsi() untuk memicu Overriding
                System.out.println("   Deskripsi: " + kopi.getDeskripsi());

                // Blok instanceof tetap dipertahankan untuk mencetak Karakter tambahan
                if (kopi instanceof KopiArabika) {
                    System.out.println("   Info Teknis: Kandungan Kafein Rendah hingga Sedang (kurang lebih 1.5%). Jenis kopi paling populer.");
                    System.out.println("   Rekomendasi Seduh: Pour Over (V60/Chemex) untuk menonjolkan aroma bunga dan buah.");
                } else if (kopi instanceof KopiRobusta) {
                    System.out.println("   Info Teknis: Kandungan Kafein Tinggi (kurang lebih 2.5%). Sering digunakan untuk espresso atau kopi instan.");
                    System.out.println("   Rekomendasi Seduh: Espresso atau Tubruk karena menghasilkan crema tebal dan body kuat.");
                } else if (kopi instanceof KopiLiberika) {
                    System.out.println("   Info Teknis: Kandungan Kafein Sangat Rendah (kurang lebih 1.2%). Termasuk jenis langka dengan produksi terbatas.");
                    System.out.println("   Rekomendasi Seduh: French Press untuk menangkap body dan keunikan rasa yang kompleks.");
                }
                System.out.println("---------------------------------");
                found = true;
                i++;
            }
        }

        if (!found) {
            System.out.println("Tidak ada kopi yang cocok dengan pencarianmu.");
        }
    }

    public boolean isEmpty() {
        return daftarKopi.isEmpty();
    }
}