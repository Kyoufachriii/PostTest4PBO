/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author fachr
 */
public class KopiLiberika extends Kopi{
    public KopiLiberika(String nama, String asal, String keasaman, String aroma) {
        super(nama, asal, "Liberika", keasaman, aroma);
    }
    @Override
    public String getDeskripsi() {
        return "Kopi Liberika memiliki profil rasa yang unik, terkadang dengan nuansa buah tropis atau aroma asap.";
    }
}