/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author fachr
 */
public class KopiArabika extends Kopi{ 
    public KopiArabika(String nama, String asal, String keasaman, String aroma) {
        super(nama, asal, "Arabika", keasaman, aroma);
    }
    
   @Override
    public String getDeskripsi() {
        return "Kopi Arabika memiliki rasa yang lebih lembut, keasaman tinggi, dan aroma wangi bunga.";
    }
}